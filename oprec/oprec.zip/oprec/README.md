# Training and Recruitment ARC Day 5

### How to access this source code using XAMPP via browser

1. save this folder (oprec folder) in C:\xampp\htdocs\

2. Run your XAMPP and start apache

3. Open your browser (Chrome/Firefox) and type "localhost/oprec" in the url field

4. press enter and the website appears